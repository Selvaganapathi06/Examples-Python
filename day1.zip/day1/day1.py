#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("HI")


# In[4]:


(/se)
print("hi")


# In[5]:


import sys
sys.version


# In[6]:


a = "selva"
print(a)

#commenting
print("example of comments")
# In[11]:


#variable declaration. we can assign same variable multiple values it will take recent one

a ="selva"
a ="ganapathi"
print(a)


# In[12]:


#variable name will be start only charecter and _ not in numbers
_a = "selva"
2a = "ganapathi"
a = "selva ganapathi"

print(_a)
print(2a)
print(a)


# In[13]:


#assisan variavle name have space it will throwing error

first name = "selva"
print(first name)


# In[17]:


#string methods
a="selva ganapathi"
print(a.title())
print(a.lower())
print(a.upper())


# In[ ]:




